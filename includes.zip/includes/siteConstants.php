<?php
	define("DOCTYPE", "xxxxxxx");
	define("BASEHREF", "xxxxxxx");
	define("BASEURL", BASEHREF);
	define("BASEDIR", "xxxxxxxx");
	define("METADESCRIPTION","Jason McCarrell's awesome website!");
	define("METAKEYWORDS","Jason,mccarrell,jason mccarrell,awesome");

	//Database constants
	define("LOCALSERVER", "localhost");
	define("JAYEH_DATABASE","xxxxxx");
	define("USERNAME", "xxxxx");
	define("PASSWORD", "xxxxx");
	
?>
