<?php //TODO: replace all strFunction js things with strAJAXFunction and make sure they work they way they're supposed to like setup wise... same with the php functions actually... some php functions won't be expecting an array as a parameter. Remember they all have AJAX int he function name upper case.
	// Call the AJAX function
	if($_POST["strAJAXFunction"]!="") {
		$GLOBALS['isAJAXCall'] = true;
		$strAJAXFunction = $_POST['strAJAXFunction'];
		unset($_POST['strAJAXFunction']);
		$strAJAXFunction($_POST);
		exit(0);
	}
?>
