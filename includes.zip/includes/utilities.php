<?php

	function jsHTMLTag($jsFile)
	{
		return	"<script type='text/javascript' language='JavaScript' src='$jsFile'></script>";
	}

	function cssHTMLTag($cssFile)
	{
		return "<link rel='stylesheet' type='text/css' href='$cssFile' />";
	}

	function googleAnalyticsCode()
	{
		ob_start();
?>
			<script type="text/javascript">
				var gaJsHost = (("https:" == document.location.protocol) ? 
				"https://ssl." : "http://www.");
				document.write(unescape("%3Cscript src='" + gaJsHost + 
				"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
				</script>
				<script type="text/javascript">
				try {
				var pageTracker = _gat._getTracker("UA-6496538-1");
				pageTracker._trackPageview();
				} catch(err) {}
			</script>
<?
			$strHTML	= ob_get_contents();
			ob_end_clean();

			return $strHTML;	
	}

	function getRandomString($length=32)
	{
		$string = "";
		for($i=0; $i<$length; $i++)
			$string .= getRandomChar();

		return $string;
	}

	function getRandomChar()
	{
		return chr(65 + (rand()%26));
	}

	define("DAY_IN_SECONDS", 86400);
	function getColourRepresentingAge($timeToCompare)
	{
		$currentTime = time();
		$differenceInTime = $currentTime - $timeToCompare;		

		if			($differenceInTime < DAY_IN_SECONDS)
			return "iblue";
		else if	($differenceInTime < (DAY_IN_SECONDS * 7))
			return "igreen";
		else if	($differenceInTime < (DAY_IN_SECONDS * 30))
			return "ifreshYellow";
		else if	($differenceInTime < (DAY_IN_SECONDS * 30 * 6))
			return "istaleYellow";
		else
			return "idarkGray";
	}
?>
